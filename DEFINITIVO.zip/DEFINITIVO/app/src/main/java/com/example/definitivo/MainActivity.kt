package com.example.definitivo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var editTextResultado: EditText
    private lateinit var textViewHistorial: TextView

    private var operando: Double = 0.0
    private var operacion: Operacion? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextResultado = findViewById(R.id.editTextResult)
        textViewHistorial = findViewById(R.id.textViewHistory)

        val boton0: Button = findViewById(R.id.button0)
        val boton1: Button = findViewById(R.id.button1)
        val boton2: Button = findViewById(R.id.button2)
        val boton3: Button = findViewById(R.id.button3)
        val boton4: Button = findViewById(R.id.button4)
        val boton5: Button = findViewById(R.id.button5)
        val boton6: Button = findViewById(R.id.button6)
        val boton7: Button = findViewById(R.id.button7)
        val boton8: Button = findViewById(R.id.button8)
        val boton9: Button = findViewById(R.id.button9)
        val botonSumar: Button = findViewById(R.id.buttonAdd)
        val botonRestar: Button = findViewById(R.id.buttonSubtract)
        val botonMultiplicar: Button = findViewById(R.id.buttonMultiply)
        val botonDividir: Button = findViewById(R.id.buttonDivide)
        val botonReset: Button = findViewById(R.id.buttonClear)
        val botonIgual: Button = findViewById(R.id.buttonEquals)

        val botonesNumero = listOf(boton0, boton1, boton2, boton3, boton4, boton5, boton6, boton7, boton8, boton9)

        for (boton in botonesNumero) {
            boton.setOnClickListener { clicarNumero(boton) }
        }

        botonSumar.setOnClickListener { clicarOperacion(Operacion.SUMAR) }
        botonRestar.setOnClickListener { clicarOperacion(Operacion.RESTAR) }
        botonMultiplicar.setOnClickListener { clicarOperacion(Operacion.MULTIPLICAR) }
        botonDividir.setOnClickListener { clicarOperacion(Operacion.DIVIDIR) }
        botonReset.setOnClickListener { clicarReset() }
        botonIgual.setOnClickListener { clicarIgual() }
    }

    private fun clicarNumero(boton: Button) {
        val textoActual = editTextResultado.text.toString()
        val nuevoTexto = textoActual + boton.text
        editTextResultado.setText(nuevoTexto)
    }

    private fun clicarOperacion(operacion: Operacion) {
        val textoActual = editTextResultado.text.toString()
        if (textoActual.isNotEmpty()) {
            operando = textoActual.toDouble()
            this.operacion = operacion
            textViewHistorial.text = "$textoActual ${operacion.simbolo}"
            editTextResultado.setText("")
        }
    }

    private fun clicarIgual() {
        val textoActual = editTextResultado.text.toString()
        if (textoActual.isNotEmpty() && operacion != null) {
            val segundoOperando = textoActual.toDouble()
            val resultado = when (operacion) {
                Operacion.SUMAR -> operando + segundoOperando
                Operacion.RESTAR -> operando - segundoOperando
                Operacion.MULTIPLICAR -> operando * segundoOperando
                Operacion.DIVIDIR -> {
                    if (segundoOperando != 0.0) {
                        operando / segundoOperando
                    } else {
                        editTextResultado.setText("Error: Div 0")
                        return
                    }
                }
                else -> return
            }
            editTextResultado.setText(resultado.toString())
            textViewHistorial.text = ""
        }
    }

    private fun clicarReset() {
        editTextResultado.setText("")
        textViewHistorial.text = ""
        operando = 0.0
        operacion = null
    }

    enum class Operacion(val simbolo: String) {
        SUMAR("+"), RESTAR("-"), MULTIPLICAR("*"), DIVIDIR("/")
    }
}